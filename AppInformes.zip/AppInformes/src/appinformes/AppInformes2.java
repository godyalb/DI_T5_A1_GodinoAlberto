
package appinformes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class AppInformes2 extends Application   
{
    public static Connection conexion = null;
    @Override
    public void start(Stage primaryStage) {
        //establecemos la conexión con la BD
        conectaBD();
        //Creamos la escena
     
        StackPane root = new StackPane();
        MenuItem listado = new MenuItem("Listado Facturas");
        MenuItem ventas = new MenuItem("Ventas Totales");
        MenuItem factura = new MenuItem("Facturas por cliente");
        MenuItem subinforme = new Menu("Subinforme Listado de facturas");
        Menu informes = new Menu("Informes");
        informes.getItems().addAll(listado,ventas,factura,subinforme);
        Menu salida = new Menu("Salida");
        MenuBar mb = new MenuBar(informes,salida);
        
        listado.setOnAction(new EventHandler<ActionEvent>() 
        {
            @Override
            public void handle(ActionEvent event) 
            {
                try 
                {
                    listado();
                } catch (JRException ex) 
                {
                    Logger.getLogger(AppInformes2.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        ventas.setOnAction(new EventHandler<ActionEvent>() 
        {
            @Override
            public void handle(ActionEvent event) 
            {
                try 
                {
                    ventas();
                } catch (JRException ex) 
                {
                    Logger.getLogger(AppInformes2.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        factura.setOnAction(new EventHandler<ActionEvent>() 
        {
            @Override
            public void handle(ActionEvent event) 
            {
                try 
                {
                    facturaPorCliente();
                } catch (JRException ex) 
                {
                    Logger.getLogger(AppInformes2.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        subinforme.setOnAction(new EventHandler<ActionEvent>() 
        {
            @Override
            public void handle(ActionEvent event) 
            {
                try 
                {
                    listadoFacturaSubinformes();
                } catch (JRException ex) 
                {
                    Logger.getLogger(AppInformes2.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        Scene scene = new Scene(root, 300, 250);
        root.getChildren().add(mb);
        
        primaryStage.setTitle("AppInformes");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    @Override
    public void stop() throws Exception {
        try {
            
            DriverManager.getConnection("jdbc:hsqldb:hsql://localhost;shutdown=true");
        } catch (Exception ex) {
                System.out.println("No se pudo cerrar la conexion a la BD");
        } 
    }
    
    
    public void conectaBD(){
        //Establecemos conexión con la BD
        String baseDatos = "jdbc:hsqldb:hsql://localhost:9001/xdb";
        
//        String baseDatos = "jdbc:hsqldb:file:C:\\Users\\usuario\\Documents\\DA\\hsqldb-2.5.0\\hsqldb\\dataDB1";
        
        String usuario = "SA";
        String clave = "";
    
        try{
            Class.forName("org.hsqldb.jdbcDriver").newInstance();
            conexion = DriverManager.getConnection(baseDatos,usuario,clave);
        }
        catch (ClassNotFoundException cnfe){
            System.err.println("Fallo al cargar JDBC");
            System.exit(1);
        }
        catch (SQLException sqle){
            System.err.println("No se pudo conectar a BD");
            System.exit(1);
        }
        catch (java.lang.InstantiationException sqlex){
            System.err.println("Imposible Conectar");
            System.exit(1);
        }
        catch (Exception ex){
            System.err.println("Imposible Conectar");
            System.exit(1);
        }
    }
   
    /**
    * @param args the command line arguments
    */
    public static void main(String[] args) {
        launch(args);
    }


    public void listado() throws JRException
    {
        try
        {
            JasperReport jr = (JasperReport)JRLoader.loadObject(AppInformes2.class.getResource("facturas.jasper"));
            Map parametros = new HashMap<String, Object>();
            JasperPrint jp = (JasperPrint) JasperFillManager.fillReport(jr, null, conexion); 
            JasperViewer jv = new JasperViewer(jp); jv.setDefaultCloseOperation(JasperViewer.DISPOSE_ON_CLOSE); 
            jv.setTitle("Etiquetas"); 
            jv.setZoomRatio((float) 1.25); 
            jv.setExtendedState(JasperViewer.MAXIMIZED_BOTH); 
            jv.requestFocus(); jv.setVisible(true); 
        } 
        catch (JRException ex) 
        { 
            System.out.println("Error al recuperar el jasper"); JOptionPane.showMessageDialog(null, ex);
        }
    }
    
    public void ventas() throws JRException
    {
        try
        {
            JasperReport jr = (JasperReport)JRLoader.loadObject(AppInformes2.class.getResource("Ventas_Totales.jasper"));
            Map parametros = new HashMap<String, Object>();
            JasperPrint jp = (JasperPrint) JasperFillManager.fillReport(jr, null, conexion); 
            JasperViewer jv = new JasperViewer(jp); jv.setDefaultCloseOperation(JasperViewer.DISPOSE_ON_CLOSE); 
            jv.setTitle("Etiquetas"); 
            jv.setZoomRatio((float) 1.25); 
            jv.setExtendedState(JasperViewer.MAXIMIZED_BOTH); 
            jv.requestFocus(); jv.setVisible(true); 
        } 
        catch (JRException ex) 
        { 
            System.out.println("Error al recuperar el jasper"); JOptionPane.showMessageDialog(null, ex);
        }
    }
    
    public void facturaPorCliente() throws JRException
    {
        try
        {
            JasperReport jr = (JasperReport)JRLoader.loadObject(AppInformes2.class.getResource("Facturas_por_Clientes.jasper"));
            Map parametros = new HashMap<String, Object>();
            JasperPrint jp = (JasperPrint) JasperFillManager.fillReport(jr, null, conexion); 
            JasperViewer jv = new JasperViewer(jp); jv.setDefaultCloseOperation(JasperViewer.DISPOSE_ON_CLOSE); 
            jv.setTitle("Etiquetas"); 
            jv.setZoomRatio((float) 1.25); 
            jv.setExtendedState(JasperViewer.MAXIMIZED_BOTH); 
            jv.requestFocus(); jv.setVisible(true); 
        } 
        catch (JRException ex) 
        { 
            System.out.println("Error al recuperar el jasper"); JOptionPane.showMessageDialog(null, ex);
        }
    }
    
    public void listadoFacturaSubinformes() throws JRException
    {
        try
        {
            JasperReport jr = (JasperReport)JRLoader.loadObject(AppInformes2.class.getResource("FacturasSubinformes.jasper"));
            Map parametros = new HashMap<String, Object>();
            JasperPrint jp = (JasperPrint) JasperFillManager.fillReport(jr, null, conexion); 
            JasperViewer jv = new JasperViewer(jp); jv.setDefaultCloseOperation(JasperViewer.DISPOSE_ON_CLOSE); 
            jv.setTitle("Etiquetas"); 
            jv.setZoomRatio((float) 1.25); 
            jv.setExtendedState(JasperViewer.MAXIMIZED_BOTH); 
            jv.requestFocus(); jv.setVisible(true); 
        } 
        catch (JRException ex) 
        { 
            System.out.println("Error al recuperar el jasper"); JOptionPane.showMessageDialog(null, ex);
        }
    }

} // Fin AppInformes2